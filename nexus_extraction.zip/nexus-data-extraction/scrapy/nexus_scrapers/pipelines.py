# Define your item pipelines here

import boto3
import os
import psycopg2
import datetime
import json
import uuid

from dotenv import load_dotenv

load_dotenv()

from nexus_scrapers.spiders.reonomy import ReonomySpider

from scrapy import signals

#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter

AWS_ACCESS_KEY_ID = os.environ.get("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.environ.get("AWS_SECRET_ACCESS_KEY")


class NexusScrapersPipeline:
    def __init__(self):
        """
        This pipeline object is an instance of a scrapy pipeline that handles item processing. It's main function is to batch
        properties into groups of 50 and send them to the bronze S3 bucket. It is not currently optimized and can be improve for
        legibility and performance.

        Inputs required:
            session credientials: The AWS_ACCESS_KEY AND SECRET ACCESS KEY for connecting to the S3 instance of our company account

            connection details for postgres database: These details are important to connect to the RDS instance and input metadata for the
            properties being processed by our scraper

        """
        session = boto3.Session(
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        )

        # Creating S3 Resource From the Session.
        self.s3 = session.resource("s3")

        now = datetime.datetime.utcnow()

        # The now instance is denominated in UTC 0 time for commonality over several time zones

        self.ymdhm = f"{now.year}-{now.month}-{now.day}-{now.hour}-{now.minute}"
        self.now_timestamp = int(now.timestamp())

        self.conn = psycopg2.connect(
            database="postgres",
            user="nexus_dev",
            password="Alex6581!",
            host="nexus-database.c0n44saktvjz.us-east-1.rds.amazonaws.com",
            port="5432",
        )

        self.items = []

    def process_item(self, item, spider):

        self.items.append(item)

        print(len(self.items))

        ids = [item["summary"]["id"] for item in self.items]

        print(ids)

        if len(self.items) >= 50:  # Batch size of file

            self.send_items_to_bucket()

        return len(self.items)

    def close_spider(self, spider):

        print("SPIDER CLOSING...")

        if len(self.items) > 0:

            self.send_items_to_bucket()

        self.conn.close()

        print("Connection closed")

    def query_sql(self, query, conn):

        cursor = conn.cursor()
        cursor.execute(query)

        conn.commit()
        conn.rollback()

        print("Query successful")

    def send_bulk_ids(self, id_list, file_id, now_timestamp):
        """_summary_

        Args:
            id_list (_type_): _description_
            file_id (_type_): _description_
            now_timestamp (_type_): _description_

        Returns:
            int: _description_
        """
        tuples_to_insert = []

        for prop_id in id_list:
            prop_tuple = (prop_id, file_id, now_timestamp, self.ymdhm)
            tuples_to_insert.append(prop_tuple)

        tuple_string = str(tuples_to_insert)

        sql_query = f"INSERT INTO landing_zone_reonomy(reonomy_id, file_id, timestamp_scraped, partition_date) VALUES {tuple_string[1:-1]}"

        self.query_sql(sql_query, self.conn)

    def send_items_to_bucket(self):
        ids = [item["summary"]["id"] for item in self.items]

        file_id = str(uuid.uuid4())

        json_data = json.dumps(self.items)

        boto_object = self.s3.Object(
            "nexus-equities-reonomy-bronze-bucket",
            f"scrapy/{self.ymdhm}/{file_id}.json",
        )
        result = boto_object.put(Body=(bytes(json_data.encode("UTF-8"))))

        if result["ResponseMetadata"]["HTTPStatusCode"] == 200:
            self.send_bulk_ids(ids, file_id, self.now_timestamp)
            self.items = []

        else:
            print("BUCKET FAILED TO UPLOAD DATA")
            return result
