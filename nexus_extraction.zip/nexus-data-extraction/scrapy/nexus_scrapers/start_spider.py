from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from spiders.reonomy import ReonomySpider

import logging

import sys

msa = sys.argv[1]
bearer_token = sys.argv[2]

if isinstance(msa, str) and isinstance(bearer_token, str):
    process = CrawlerProcess(get_project_settings())
    process.crawl(ReonomySpider, msa=msa, auth_token=bearer_token)
    process.start()

# process = CrawlerProcess(get_project_settings())
# process.crawl(ReonomySpider(msa, bearer_token))
# process.start()
