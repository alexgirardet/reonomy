import datetime
import logging
import json
import os

import psycopg2
import scrapy
from scrapy import signals
from scrapy.utils.project import get_project_settings

from dotenv import load_dotenv

load_dotenv()


session_logging = logging.getLogger(__name__)
session_logging.setLevel(logging.INFO)

session_file_handler = logging.FileHandler("session.log")

session_logging.addHandler(session_file_handler)


AWS_POSTGRES_PASSWORD = os.environ.get("AWS_POSTGRES_PASSWORD")


class ReonomySpider(scrapy.Spider):

    """This ReonomySpider class instantiates a Scrapy Spider that can be configured to enable asynchronous scraping.

    In this case our Spider is designed to interact with the Reonomy API and extract JSON objects of individual properties
    on the site.

    Combined with the pipeline file, this scraper sends multiple different requests to the reonomy api, extracts
    the data and processes it using the pipeline to send file sizes of 50 properties to our AWS cloud bucket, as well as
    store each properties metadata onto a cloud Postgres instance.

    It is very important to make sure that you instantiate the spider using the cmd 'scrapy crawl reonomy' in the command
    line while you are in the scrapy directory. Ideally each scrapy session will continue until it ends by itself, but
    if you need to prematurely end a session use 'CRTL C'. Only click it ONCE. This is very important as it will allow the
    closing processes within the spider and pipeline classes to take place.

    Attributes:
        auth_token (str): This token is required to authenticate Reonomy API requests, it can be fetched by logging on into reonomy,
        sending a request to the API and extracting it from the network requests features on your browser.

        msa (str): This is the metropolitan statistical area of where the sites you are filtering for are situated in, you must input
        this to specify which area you would like to target.

        current_ids (list): A list of all ids that have been extracted from our filter requests. Used to count the number of sites
        within a current MSA, and avoid data duplication.

        headers (dict): A dictionary representing the headers of our HTTP requests to the reonomy API. This is used to simulate a more
        human like request.

        test (bool): A boolean state of True if we want our scraper to go into test mode meaning it will not serve data to our cloud instances and impact our buckets
        else False implying it is in production state.

    """

    name = "reonomy"

    URL_V2 = "https://api.reonomy.com/v2"
    URL_V3 = "https://api.reonomy.com/v3"

    # handle_httpstatus_list = [200, 400]
    # Name of the spider for the scrapy framework to recognise

    def __init__(self, msa=None, auth_token=None):

        """Inits ReonomySpider and associated attributes for current scraping session."""

        settings = get_project_settings()

        # self.test = settings["TEST_STATE"]  # Are we currently running a test session

        self.test = False

        # self.auth_token = (
        #     "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlJUWkdOamN3TlVVMFJFTTJORGt6UlRNd1JVSTVSVGs1TlVZeE56UkRNVUUzUlVNd09UTkVOdyJ9.eyJpc3MiOiJodHRwczovL2F1dGgucmVvbm9teS5jb20vIiwic3ViIjoiYXV0aDB8NTYwZDg2MDItNjc2OC00ODliLWEzYjAtMzI5ZTkxZjJmNDE0IiwiYXVkIjpbImh0dHBzOi8vYXBwLnJlb25vbXkuY29tL3YyLyIsImh0dHBzOi8vcmVvbm9teS1wcmQuYXV0aDAuY29tL3VzZXJpbmZvIl0sImlhdCI6MTY2ODAxODk2MCwiZXhwIjoxNjY4MTA1MzYwLCJhenAiOiJVVHFqSVpmNWpxRTBSb1JDSlBEMjE2YVQ5Q1dacnEyQyIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwifQ.WiH8wFW2tnY1BnsmQpKgLfvFN1orSQgIL1gbCyVYf3BbXx3wuzm_Y9AxFq7lpYZO8m8SYVbh9gdif4oKFMWJNC1dJCuMCfxF5X7DielgUKesMoV-jYNZEAy-HWQkQ-I3EPc-FuV-lcS0Ac87h_2T5gUilX2HESWVa_VY2SAhz8PQPk3i6DpxFplNQ-MUSeiHiaUs-R54UeWxUNeGl8Lp_0KIFCzyRybAXOwE7QDPja7QgUui7NeYC-g54d3kEfGGHy6TRQFqAp3rMDbnTYR5AqVQDz1GP76HGeYFiowrlaAnjcxlsI2C1lqsnd3Hf9gGP1ALlkAyBDp3gw7u31ESVA"
        # )

        self.auth_token = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlJUWkdOamN3TlVVMFJFTTJORGt6UlRNd1JVSTVSVGs1TlVZeE56UkRNVUUzUlVNd09UTkVOdyJ9.eyJpc3MiOiJodHRwczovL2F1dGgucmVvbm9teS5jb20vIiwic3ViIjoiYXV0aDB8NmJkMWMyZjQtYTM0YS00NDUzLThlOGQtOGQ5ZTViNmQ1OTM1IiwiYXVkIjpbImh0dHBzOi8vYXBwLnJlb25vbXkuY29tL3YyLyIsImh0dHBzOi8vcmVvbm9teS1wcmQuYXV0aDAuY29tL3VzZXJpbmZvIl0sImlhdCI6MTY2ODc3NDc1MiwiZXhwIjoxNjY4ODYxMTUyLCJhenAiOiJVVHFqSVpmNWpxRTBSb1JDSlBEMjE2YVQ5Q1dacnEyQyIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwifQ.Dvy5UwH6LDnN43Jrrn_dXwYuCq5Q7TkJnCTAWjGp7rXljbd-LQKaBDvZrFn1gKbn0TkQkIsQ0CJfwWfaNdpLSeD7HIj3ejLvEqLTGlnouR3oTZq3uOXOWhcJl5holVT7o1RUEkN0b2JRergYLE2uiFfL3czdwpmWPMjVUljNxZ0JF46QRYkJ4xmrlM6_lm2z6COBYKbPP62yt-5F7yAGK0c6eaHOQHP2l0dZrtr1fGFSMDN-UdSAMbmXyRf6KHPHTcMkMigI-Jd_zBsXd9cPwEDz_kLuAhlbphiWcS-m8eXuQoeJf5ER9zYzGouoHYkvj_sDn-TKJ0oAd1npvDhfGQ"
        # Bearer token from Reonomy, needs to be inputted for each session. Try using a VPN when running this spider.

        self.msa = msa
        # Current msa of the scrapy session

        self.current_ids = set()

        self.headers = {
            "authority": "api.reonomy.com",
            "accept": "*/*",
            "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
            "authorization": self.auth_token,
            "content-type": "application/json",
            "origin": "https://app.reonomy.com",
            "referer": "https://app.reonomy.com/",
            "sec-ch-ua": '"Chromium";v="104", " Not A;Brand";v="99", "Google Chrome";v="104"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"macOS"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36",
        }  # Headers that will be sent in API requests to replicate real user

        session_logging.info(f"Initializing Scrapy session for {self.msa}")

    def pg_connect(self):
        """Connect to postgres database instance.

        Returns:
            conn (object): psycopg2 connection object, to be used to interact with database
        """

        conn = psycopg2.connect(
            database="postgres",
            user="nexus_dev",
            password=AWS_POSTGRES_PASSWORD,  # Handle password with env file
            host="nexus-database.c0n44saktvjz.us-east-1.rds.amazonaws.com",
            port="5432",
        )
        # Connection details for AWS Relational Database Services Postgres Instance

        session_logging.debug("Connected to Postgres Instance")

        return conn

    def fetch_stored_ids(self, msa: str) -> list:
        """Fetches ids of the current MSA from our AWS postgres database.

        Retrives all IDs that are already currently stored in our data lake to avoid data duplication.
        These ids will be compared to the property ids returned by the scraper and will subsequently drop any further scraping of properties
        that are already in our database.

        Args:
            msa (str): The current MSA we are extracting data from, this will prevent us from querying for all the IDs in the database to reduce memory burden.

        Returns (list):
            A list of all ids within the current MSA that are already in our data lake. Each list item is a string representing the ID.
        """

        conn = self.pg_connect()
        cursor = conn.cursor()
        cursor.execute("SELECT reonomy_id from landing_zone_reonomy")
        fetched_ids = cursor.fetchall()
        stored_ids = [id_[0] for id_ in fetched_ids]
        # Get the IDs of properties that have already been fetched and stored within the S3 bucket to avoid duplicating data

        conn.close()

        session_logging.debug("Stored ids extracted")
        session_logging.debug("Postgres instance connection closed")

        return stored_ids

    def start_requests(self) -> object:
        """Generator that loops through a search filter and returns matching property ids

        Retrieves the property ids that match the requested filter from the Reonomy API

        Yields (object):
            A response that includes the first 1000 matching properties as well as the count of properties, initiates the start_acres_requests function
        """

        self.stored_ids = self.fetch_stored_ids(self.msa)

        # for acres_size in range(1, 3):
        #     payload = self.gen_payload(acres_size)

        #     # The gen payload function be found below and returns the necessary payload for a filter request to the API based on the acre size
        #     url = ReonomySpider.URL_V2 + "/search/pins?offset=0&limit=1000"

        #     yield scrapy.Request(
        #         method="POST",
        #         url=url,
        #         headers=self.headers,
        #         body=payload,
        #         callback=self.start_acres_requests,
        #         meta={"payload": payload},
        #     )

        payload = self.gen_payload()

            # The gen payload function be found below and returns the necessary payload for a filter request to the API based on the acre size
        url = ReonomySpider.URL_V2 + "/search/pins?offset=0&limit=1000"

        yield scrapy.Request(
            method="POST",
            url=url,
            headers=self.headers,
            body=payload,
            callback=self.start_acres_requests,
            meta={"payload": payload},
        )



    def start_acres_requests(self, response: object) -> object:
        """Generator that loops through the search filter and returns matching property ids

        Loops through all the matching property ids by iterating over the filter match count, and offsetting the request.

        Args (object):
            response: HTTP response from start_requests, contains the first 1000 matching properties as well as the count of properties

        Yields (object):
            A response that includes the associated matching properties based on their offset, initiates the parse_filters function
        """

        # As filter requests can have more than 1000 properties returned we must send several server requests to get all properties that match the filter

        response_json = response.json()
        count = response_json["count"]
        items = response_json["items"]

        payload = response.meta["payload"]

        if count > 1000:

            # If the number of matched properties surparsses 1000, take the count and loop using all offsets until all properties are requested

            current_count = 0
            for offset in range(1000, count, 1000):
                # url = (
                #     f"https://api.reonomy.com/v2/search/pins?offset={offset}&limit=1000"
                # )
                url = ReonomySpider.URL_V2 + f"/search/pins?offset={offset}&limit=1000"

                current_count += 1

                if (
                    current_count == 1
                ):  # If this is the first filter request then save the fecthed ids as a list.
                    current_items = items
                else:
                    current_items = None

                yield scrapy.Request(
                    method="POST",
                    url=url,
                    headers=self.headers,
                    body=payload,
                    callback=self.parse_filters,
                    meta={"items": current_items},
                )
        else:  # Less than 1000 properties

            url = ReonomySpider.URL_V2 + "/search/pins?offset=0&limit=1000"

            yield scrapy.Request(
                method="POST",
                url=url,
                headers=self.headers,
                body=payload,
                callback=self.parse_filters,
                meta={"items": None},
                dont_filter=True,
            )

    def parse_filters(self, response: object):
        """Generator that fetches the HTTP summary response of the filter matching property ids.

        The summaries request on the reonomy API only accepts 50 property ids at a time, this function batches the matching ids into groups of 50 and initiates HTTP requests,
        fetching their summary data.

        Args:
            response (object): HTTP response from start_acres_requests containing the matching ids of the filter requests.
            items (list): # TODO Update

        Yields:
            response (object): HTTP response containing summary data of 50 properties at a time. Returns a JSON object of the summaries to be parsed.
        """

        if response.meta["items"]:
            filterered_properties = response.json()["items"]

            current_items = response.meta["items"]

            filterered_properties += current_items

        else:
            filterered_properties = response.json()["items"]

            # Else extract both set of properties from response and the ones passed as a meta object to be filtered and parsed

        for item in filterered_properties:
            unique_id = item["id"]
            self.current_ids.add(unique_id)

        session_logging.info(
            f"# of sites to extract in {self.msa} is {len(self.current_ids)}"
        )

        n = 50
        split_filterered_properties = [
            filterered_properties[i : i + n]
            for i in range(0, len(filterered_properties), n)
        ]

        # The summary request can only handle 50 properties of a time, we split the properties into batches of 50 to be looped through later

        for current_split in split_filterered_properties:

            current_split_ids = [current_item["id"] for current_item in current_split]

            # session_logging.info(
            #     f"There are: {len(current_split_ids)} sites in this batch"
            # )

            current_split_ids_cleaned = [
                current_split_id
                for current_split_id in current_split_ids
                if current_split_id not in self.stored_ids
            ]

            # session_logging.info(
            #     f"After filtering there are {len(current_split_ids_cleaned)} sites left to extract in this batch"
            # )

            # url = "https://api.reonomy.com/v2/property/summaries"
            url = ReonomySpider.URL_V2 + "/property/summaries"

            if not self.test:

                if (
                    len(current_split_ids_cleaned) > 0
                ):  # If there are still properties to parse in batch then initiate further scrape

                    payload = json.dumps({"property_ids": current_split_ids_cleaned})

                    yield scrapy.Request(
                        method="POST",
                        url=url,
                        headers=self.headers,
                        body=payload,
                        callback=self.parse_summaries,
                    )

                # The summary request accepts only ids, while looping through the baches we extract ids, and drop ones that are already stored in our buckets
                else:
                    pass
            else:
                #     session_logging.info(
                #     f"After filtering there are {len(current_split_ids_cleaned)} sites left to extract in this batch"
                # )
                pass

    def parse_summaries(self, response: object):
        """Parses the summary JSON responses from the parse_filters generator.

        This function handles the response containing batched summaries, it also creates the first iteration of the property_dict
        which acts as the dictionary object that will contain all data relating to a single property. This object will be passed to other
        functions as meta objects in subsequent HTTP requests.

        Args:
            response (object): Response JSON object from parse_filters

        Yields:
                shapes_response (object): Response containing a JSON object of the shapes of a property, containing the property_dict object of a property as metadata to be passed through.
            OR:
                details_response (object): Response containing a JSON object of the details of a property, containing the property_dict object of a property as metadata to be passed through.
        """

        summaries = response.json()

        if response.status == 400:  # TO DO how to handle 400 error requests
            print("ERROR 400", response.status, response.body)
            print("BODY HERE", response.text, response.request, response.headers)

        for summary in summaries:

            property_dict = {}

            property_dict["summary"] = summary
            property_dict["scraping_details"] = {}

            # check if parcels and add details
            if "parcel_shape_ids" in summary.keys():
                property_dict["scraping_details"]["shape_ids"] = summary[
                    "parcel_shape_ids"
                ]

            property_dict["scraping_details"]["property_id"] = summary["id"]
            property_dict["scraping_details"][
                "datetime_scraped"
            ] = datetime.datetime.now().strftime("%m/%d/%Y, %H:%M:%S")
            property_dict["shapes"] = {}

            if (
                "shape_ids" in property_dict["scraping_details"].keys()
            ):  # If property has shape id, then it means it can be further extracted from the API

                url = ReonomySpider.URL_V2 + "/search/property-shapes"

                payload = json.dumps(
                    {"shape_ids": property_dict["scraping_details"]["shape_ids"]}
                )

                yield scrapy.Request(
                    method="POST",
                    url=url,
                    headers=self.headers,
                    body=payload,
                    callback=self.parse_shapes,
                    meta=property_dict,
                )

            else:  # Skip shapes request

                property_dict["scraping_details"][
                    "shape_ids"
                ] = None  # Set the property shape id in property_dict object to none

                # url = f"https://api.reonomy.com/v2/property/{property_dict['scraping_details']['property_id']}"
                url = (
                    ReonomySpider.URL_V2
                    + f"/property/{property_dict['scraping_details']['property_id']}"
                )

                # session_logging.info(f"{property_dict['scraping_details']['property_id']} is being sent to parse_details")

                yield scrapy.Request(
                    method="GET",
                    url=url,
                    headers=self.headers,
                    callback=self.parse_details,
                    meta=property_dict,
                )

    def parse_shapes(self, response):

        """Parses shapes JSON object from the parse summaries generator.

        This function will take the HTTP response containing the shapes JSON object of a property, extract the property_dict and add the shapes JSON object to the
        property dict.

        Args:
            response: response object from parse_summaries generator, containing the JSON object of the shapes object of the property.

        Yields:
            Response containing a JSON object of the details of a property, containing the property_dict object of a property as metadata to be passed through.

        """

        shapes = response.json()

        property_dict = response.meta

        property_dict["shapes"]["count"] = shapes["count"]
        property_dict["shapes"]["items"] = shapes["items"]

        # url = f"https://api.reonomy.com/v2/property/{property_dict['scraping_details']['property_id']}"
        url = (
            ReonomySpider.URL_V2
            + f"/property/{property_dict['scraping_details']['property_id']}"
        )

        yield scrapy.Request(
            method="GET",
            url=url,
            headers=self.headers,
            callback=self.parse_details,
            meta=property_dict,
        )

    def parse_details(self, response: object):

        """Parses details JSON object from the parse summaries or parse_shapes generator.

        This function will take the HTTP response containing the details JSON object of a property, extract the property_dict and add the details JSON object to the
        property dict.

        Args:
            response (object): response object from parse_summaries or parse_shapes generator, containing the JSON object of the shapes object of the property.

        Yields:
            property_contacts_response (object): Response containing a JSON object of the property contacts of a property, containing the property_dict object of a property as metadata to be passed through.

        """

        details = response.json()
        property_dict = response.meta
        property_dict["details"] = details

        # PARSE OWNERS

        # url = f"https://api.reonomy.com/v3/property-contacts/{property_dict['scraping_details']['property_id']}"
        url = (
            ReonomySpider.URL_V3
            + f"/property-contacts/{property_dict['scraping_details']['property_id']}"
        )

        yield scrapy.Request(
            method="GET",
            url=url,
            headers=self.headers,
            callback=self.parse_owners,
            meta=property_dict,
        )

    def parse_owners(self, response: object):
        """Parses property owners JSON object from the parse details generator.

        This function will take the HTTP response containing the property owners JSON object of a property, extract the property_dict and add the property owners JSON object to the
        property dict.

        Args:
            response (object): response object from parse_details generator, containing the JSON object of the property contacts object of the property.

        Yields:
                bulk_contact_response (object): Response containing the specific people bulk information, containing the property_dict object of a property as metadata to be passed through.
            OR:
                tenants_response (object): Response containing a JSON object of the tenants of a property, containing the property_dict object of a property as metadata to be passed through.

        #TODO: This is a complicated function that might not be properly configured, it would be worthwhile to add some checks
        to ensure that it is working smoothly. Look through the logic.
        """

        property_dict = response.meta

        owners = response.json()

        property_dict["property_contacts"] = {}

        if "contacts" in owners.keys():

            contacts = owners["contacts"]

            property_dict["property_contacts"]["contacts"] = contacts

        else:  # If there is no company then there is a individual owner
            if "owners" in owners.keys():
                property_dict["property_contacts"]["individual_contact"] = {}
                owner = owners["owners"][0]
                property_dict["property_contacts"]["individual_contact"][
                    "owner"
                ] = owner

        if "owners" in owners.keys():
            property_dict["property_contacts"]["owner_id"] = owners["owners"][0]["id"]

        if "individual_contact" in property_dict["property_contacts"].keys():
            property_dict["property_contacts"]["is_contacts"] = False
            property_dict["property_contacts"]["is_individual_contact"] = True
        elif "contacts" in property_dict["property_contacts"]:
            property_dict["property_contacts"]["is_individual_contact"] = False
            property_dict["property_contacts"]["is_contacts"] = True
        else:  # Skip contacts
            property_dict["property_contacts"]["is_individual_contact"] = False
            property_dict["property_contacts"]["is_contacts"] = False

            # url = f"https://api.reonomy.com/v2/property/{property_dict['scraping_details']['property_id']}/tenants"
            url = (
                ReonomySpider.URL_V2
                + f"/property/{property_dict['scraping_details']['property_id']}/tenants"
            )

            yield scrapy.Request(
                method="GET",
                url=url,
                headers=self.headers,
                callback=self.parse_tenants,
                meta=property_dict,
            )

        if property_dict["property_contacts"]["is_individual_contact"]:
            owner_contact_list_ids = [
                property_dict["property_contacts"]["individual_contact"]["owner"]["id"]
            ]
        elif property_dict["property_contacts"]["is_contacts"]:
            owner_contact_list_ids = [
                contact["id"]
                for contact in property_dict["property_contacts"]["contacts"]
            ]
        else:
            owner_contact_list_ids = []

        # url = "https://api.reonomy.com/v3/people/bulk"
        url = ReonomySpider.URL_V3 + "/people/bulk"

        if len(owner_contact_list_ids) > 0:

            owner_contact_list_ids = owner_contact_list_ids[
                :99
            ]  # Request only allows 100 ids to be parsed

            payload = json.dumps({"ids": owner_contact_list_ids})

            yield scrapy.Request(
                method="POST",
                url=url,
                headers=self.headers,
                body=payload,
                callback=self.parse_owner_contacts,
                meta=property_dict,
                dont_filter=True,  # Multipe properties can have the same owners, therefore we do not filter for bulk owners
            )

        else:
            # url = f"https://api.reonomy.com/v2/property/{property_dict['scraping_details']['property_id']}/tenants"
            url = (
                ReonomySpider.URL_V2
                + f"/property/{property_dict['scraping_details']['property_id']}/tenants"
            )

            yield scrapy.Request(
                method="GET",
                url=url,
                headers=self.headers,
                callback=self.parse_tenants,
                meta=property_dict,
            )

    def parse_owner_contacts(self, response: object):

        """Parses specific bulk information JSON object from the parse summaries generator.

        This function will take the HTTP response containing the people bulk JSON information object of a property, extract the property_dict and add the people bulk object to the
        property dict.

        Args:
            parse_owners_response (object): response object from parse_owners generator, containing the JSON object of the people bulk information object of the property.

        Yields:
            tenants_response (object): Response containing a JSON object of the tenants of a property, containing the property_dict object of a property as metadata to be passed through.

        """

        if response.status == 400:  # TO DO better error handling
            print("ERROR 400", response.status, response.body)
            print("BODY HERE", response.text, response.request, response.headers)
        property_dict = response.meta

        owner_contacts = response.json()

        property_dict["property_contacts"]["contact_details"] = owner_contacts

        # url = f"https://api.reonomy.com/v2/property/{property_dict['scraping_details']['property_id']}/tenants"
        url = (
            ReonomySpider.URL_V2
            + f"/property/{property_dict['scraping_details']['property_id']}/tenants"
        )

        yield scrapy.Request(
            method="GET",
            url=url,
            headers=self.headers,
            callback=self.parse_tenants,
            meta=property_dict,
        )

    def parse_tenants(self, response: object):
        """Parses tenants JSON object from the parse_owner_contacts, or parse_owners generator.

        This function will take the HTTP response containing the tenants JSON information object of a property, extract the property_dict and add the tenants object to the
        property dict.

        Args:
            tenants_response (object): response object from parse_owner_contacts generator, containing the JSON object of the tenants information object of the property.

        Yields:
            sales_response (object): Response containing a JSON object of the sales of a property, containing the property_dict object of a property as metadata to be passed through.

        """

        tenants = response.json()

        property_dict = response.meta

        property_dict["tenants"] = tenants

        # url = f"https://api.reonomy.com/v2/property/{property_dict['scraping_details']['property_id']}/sales"
        url = (
            ReonomySpider.URL_V2
            + f"/property/{property_dict['scraping_details']['property_id']}/sales"
        )

        yield scrapy.Request(
            method="GET",
            url=url,
            headers=self.headers,
            callback=self.parse_sales,
            meta=property_dict,
        )

    def parse_sales(self, response: object):

        """Parses sales JSON object from the parse_tenants generator.

        This function will take the HTTP response containing the sales JSON information object of a property, extract the property_dict and add the sales object to the
        property dict.

        Args:
            sales_response (object): response object from parse_tenants generator, containing the JSON object of the sales information object of the property.

        Yields:
            taxes_reponse (object): Response containing a JSON object of the taxes of a property, containing the property_dict object of a property as metadata to be passed through.

        """

        sales = response.json()

        property_dict = response.meta

        property_dict["sales"] = sales

        # url = f"https://api.reonomy.com/v2/property/{property_dict['scraping_details']['property_id']}/taxes"
        url = (
            ReonomySpider.URL_V2
            + f"/property/{property_dict['scraping_details']['property_id']}/taxes"
        )

        yield scrapy.Request(
            method="GET",
            url=url,
            headers=self.headers,
            callback=self.parse_taxes,
            meta=property_dict,
        )

    def parse_taxes(self, response: object):

        """Parses taxes JSON object from the parse_sales generator.

        This function will take the HTTP response containing the taxes JSON information object of a property, extract the property_dict and add the taxes object to the
        property dict.

        Args:
            taxes_response (object): response object from parse_sales generator, containing the JSON object of the taxes information object of the property.

        Yields:
            property_dict (dict): Dictionary containing all data to be yielded to the NexusScrapersPipeline object for processing.

        """

        taxes = response.json()

        property_dict = response.meta

        property_dict["taxes"] = taxes

        yield property_dict

    # def gen_payload(self, min_acres: int):

    #     """Returns the payload for a filter request, based on the minimum amount of acres.

    #     This function will take the minimum acres argument and generate a related payload, including the max_building size and the rest of the payload.

    #     Args:
    #         min_acres (int): int representing the minimum acres.

    #     Returns:
    #         payload (object): JSON Payload containing the associated attributes based on the minimum acres.

    #     """

    #     max_building = 43560 * min_acres * 0.25

    #     payload = json.dumps(
    #         {
    #             "settings": {
    #                 "building_area": {"max": max_building},
    #                 "land_use_code": [
    #                     "806",
    #                     "0514",
    #                     "208",
    #                     "303",
    #                     "308",
    #                     "6018",
    #                     "311",
    #                     "6023",
    #                     "218",
    #                     "304",
    #                     "342",
    #                     "5005",
    #                     "6020",
    #                     "830",
    #                     "300",
    #                     "338",
    #                     "5000",
    #                     "5001",
    #                     "5008",
    #                     "5013",
    #                     "5018",
    #                     "5019",
    #                     "5020",
    #                     "6008",
    #                     "6016",
    #                     "320",
    #                     "6000",
    #                     "6015",
    #                     "321",
    #                     "5010",
    #                     "322",
    #                     "5012",
    #                     "323",
    #                     "324",
    #                     "5002",
    #                     "5006",
    #                     "5015",
    #                     "328",
    #                     "6007",
    #                     "326",
    #                     "6010",
    #                     "331",
    #                     "6019",
    #                     "349",
    #                     "6003",
    #                     "6014",
    #                     "334",
    #                     "6009",
    #                     "310",
    #                     "5016",
    #                     "5017",
    #                     "344",
    #                     "6006",
    #                     "258",
    #                     "207",
    #                     "6004",
    #                     "354",
    #                     "6011",
    #                     "358",
    #                     "5004",
    #                     "6024",
    #                     "361",
    #                     "6021",
    #                     "309",
    #                     "800",
    #                     "877",
    #                     "6001",
    #                     "6500",
    #                     "6505",
    #                     "6512",
    #                     "364",
    #                     "5003",
    #                     "6002",
    #                     "883",
    #                     "6013",
    #                     "886",
    #                     "899",
    #                 ],
    #                 "locations": [{"kind": "msa", "text": self.msa}],
    #                 "lot_size_acres": {"min": min_acres},
    #                 "sort": [{"name": "year_renovated", "order": "desc"}],
    #             },
    #             "aggregations": [{"name": "geo_bounds"}],
    #         }
    #     )

    #     return payload


    def gen_payload(self):

        payload = json.dumps({
        "settings": {
            "land_use_code": [
            "806",
            "0514",
            "208",
            "303",
            "308",
            "6018",
            "311",
            "6023",
            "218",
            "304",
            "342",
            "5005",
            "6020",
            "830",
            "300",
            "338",
            "5000",
            "5001",
            "5008",
            "5013",
            "5018",
            "5019",
            "5020",
            "6008",
            "6016",
            "320",
            "6000",
            "6015",
            "321",
            "5010",
            "322",
            "5012",
            "323",
            "324",
            "5002",
            "5006",
            "5015",
            "328",
            "6007",
            "326",
            "6010",
            "331",
            "6019",
            "349",
            "6003",
            "6014",
            "334",
            "6009",
            "310",
            "5016",
            "5017",
            "344",
            "6006",
            "258",
            "207",
            "6004",
            "354",
            "6011",
            "358",
            "5004",
            "6024",
            "361",
            "6021",
            "309",
            "800",
            "877",
            "6001",
            "6500",
            "6505",
            "6512",
            "364",
            "5003",
            "6002",
            "883",
            "6013",
            "886",
            "899"
            ],
            "locations": [
            {
                "kind": "msa",
                "text": "Dallas-Fort Worth-Arlington, TX"
            }
            ],
            "sort": [
            {
                "name": "year_renovated",
                "order": "desc"
            }
            ]
        },
        "bounding_box": {
            "bottom_right": {
            "lat": 32.60970085954357,
            "lon": -96.44074131749251
            },
            "top_left": {
            "lat": 32.74754377355487,
            "lon": -96.69892002843001
            }
        }
        })

        return payload

    
