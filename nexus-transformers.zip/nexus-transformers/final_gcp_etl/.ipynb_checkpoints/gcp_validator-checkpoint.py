from pandera import Column, DataFrameSchema, Check, Index

class ReonomyValidator:
    """This class loads the schema object from the local schema library  and implements it to be used by the silver transformer.

    Attributes:
        descriptions_schema: pandera with descriptions schema
        sales_schema: pandera object with sales schema
        taxes_schema: pandera object with taxes schema
        contacts_schema: pandera object with contacts schema
        shapes_schema: pandera object with shapes schema
        tenants_schema: pandera object with tenants schema

    """

    def __init__(self):
        """Initializes Reonomy Validator"""
        self.descriptions_schema = self.load_schema("descriptions")
        self.sales_schema = self.load_schema("sales")
        self.taxes_schema = self.load_schema("taxes")
        self.contacts_schema = self.load_schema("contacts")
        self.shapes_schema = self.load_schema("shapes")
        self.tenants_schema = self.load_schema("tenants")

    def load_schema(self, table_type: str) -> object:
        """Fetches associated schema object based on table name

        Args:
            table_type (str): Name of the schema type object to fetch

        Returns:
            schema (obj): Schema object of table_type
        """
        file_name = f"schemas/{table_type}.yaml"
        schema = DataFrameSchema.from_yaml(file_name)
        return schema