from reonomy_validator import ReonomyValidator
import pandas as pd
import logging

# logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)


class SilverTransformer:

    """This class holds all the methods and variables to complete the transformations on the reonomy bronze data.

    The purpose is to input the raw JSON reonomy data, and return 6 cleaned tables:
    shapes, property_contacts, tenants, sales, taxes and descriptions. These tables will all contain the MSA for partition
    and the reonomy id of the sites wihtin it for better querying.

    Attributes:
        columns_to_transform (list): This is a list of the column names to transform into pandas dataframes.
        validator: Instance of ReonomyValidator object.
    """

    def __init__(self):
        """Initializes SilverTransformer class."""
        self.columns_to_transform = [
            "shapes",
            "property_contacts",
            "tenants",
            "sales",
            "taxes",
            "description",
        ]
        self.validator = ReonomyValidator()

    # Active functions

    def transform_data(self, data: object) -> object:
        """Inputs reonomy_id and msa name into unnormalized data frame, and drops unwanted columns.

        This function expects a dataframe containing all columns with embdedded json objects and will do three things:
            - Drop unwanted columns
            - Add reonomy_id and msa to each embedded json object
            - Combined summary and details into new description column

        Args:
            data (dataframe): Unnormalized data frame, containing all embdedded json columns as dataframe columns

        Returns:
            df (dataframe): Unnormalized data frame with dropped columns, new description column and reonomy_id + msa in each column json object
        """

        df = data.copy()
        df["description"] = df[["summary", "details"]].apply(
            self.create_description, axis=1
        )
        df["reonomy_id"] = df["scraping_details"].apply(lambda x: x["property_id"])
        df["msa"] = df["details"].apply(lambda x: x["msa_name"])

        columns_to_keep = self.columns_to_transform + ["reonomy_id", "msa"]
        df = df[columns_to_keep]

        for column in self.columns_to_transform:
            df[column] = df[["reonomy_id", column]].apply(
                lambda x: self.insert_value(x, "reonomy_id"), axis=1
            )
            df[column] = df[["msa", column]].apply(
                lambda x: self.insert_value(x, "msa"), axis=1
            )

        return df

    def generate_tables(self, df: object):
        """Creates six class attributes containing each table type as described in columns_to_transform list.

        Args:
            df (dataframe): Expects a un-normalized dataframe with description as a column and reonomy_id + msa within each embedded json object.
        """

        df_dict = df.to_dict()

        self.description_table = self.handle_descriptions(df_dict["description"])
        # self.description_table = self.validator.descriptions_schema.validate(
        #     self.description_table
        # )
        # logger.info("Description generated and validated")

        self.sales_table = self.handle_sales(df_dict["sales"])
        self.sales_table = self.validator.sales_schema.validate(self.sales_table)
        # logger.info("Sales generated and validated")

        self.tenants_table = self.handle_tenants(df_dict["tenants"])
        self.tenants_table = self.validator.tenants_schema.validate(self.tenants_table)
        # logger.info("Tenants generated and validated")

        self.shapes_table = self.handle_shapes(df_dict["shapes"])
        self.shapes_table = self.validator.shapes_schema.validate(self.shapes_table)
        # logger.info("Shapes generated and validated")

        self.contacts_table = self.handle_contacts(df_dict["property_contacts"])
        self.contacts_table = self.validator.contacts_schema.validate(self.contacts_table)
        # logger.info("Contacts generated and validated")

        self.taxes_table = self.handle_taxes(df_dict["taxes"])
        self.taxes_table = self.validator.taxes_schema.validate(self.taxes_table)
        # logger.info("Taxes generated and validated")

    # Handler functions

    def create_description(self, x: object) -> object:
        """Creates description from summary and details columns.

        Args:
            x (two dataframe series): dataframe row contain summary and details data. Passed using axis=1 in df lambda function

        Returns:
            description (dataframe series): combined description series of summary and details columns
        """
        description = {**x[0], **x[1]}

        return description

    def insert_value(self, x: object, value_name: str):
        """Inserts value into embedded json

        Args:
            x (pandas series): two column pandas series containing the value to insert and the embedded json object
            value_name (str): _description_

        Returns:
            current_dict: embedded json with new value inserted
        """
        value = x[0]
        current_dict = x[1]

        current_dict[value_name] = value

        return current_dict

    def handle_descriptions(self, descriptions_dict: dict):
        """Transforms the descriptions dictionary into a normalized pandas tables

        Args:
            descriptions_dict (dict): Dictationary containing descriptions data

        Returns:
            desc_table (dataframe): normalized pandas dataframe containing descriptions data
        """

        description_tbl = pd.json_normalize(descriptions_dict, max_level=0).T
        description_tbl = description_tbl.rename(columns={0: "description"})

        row_length = description_tbl.shape[0]

        desc_table = pd.DataFrame()
        for i in range(row_length):
            d = description_tbl.iloc[i]["description"]
            row = pd.json_normalize(d, max_level=0)
            desc_table = pd.concat([desc_table, row])

        desc_table = desc_table.reset_index(drop=True)

        return desc_table

    def handle_sales(self, sales_dict):
        """Transforms the sales dictionary into a normalized pandas tables

        Args:
            sales_dict (dict): Dictationary containing sales data

        Returns:
            sales_table (dataframe): normalized pandas dataframe containing sales data
        """

        sales_tbl = pd.json_normalize(sales_dict, max_level=0).T
        sales_tbl = sales_tbl.rename(columns={0: "sales"})

        sales_table = pd.DataFrame()

        row_length = sales_tbl.shape[0]

        for i in range(row_length):
            row = sales_tbl.iloc[i]["sales"]

            property_sales_df = pd.json_normalize(
                row,
                max_level=0,
                record_path=["sales"],
                meta=["reonomy_id", "sale_update_time", "msa"],
            )

            sales_table = pd.concat([sales_table, property_sales_df])

        sales_table = sales_table.reset_index(drop=True)

        return sales_table

    def handle_tenants(self, tenants_dict):
        """Transforms the tenants dictionary into a normalized pandas tables

        Args:
            tenants_dict (dict): Dictationary containing tenants data

        Returns:
            tenants_table (dataframe): normalized pandas dataframe containing tenants data
        """

        tenants_tbl = pd.json_normalize(tenants_dict, max_level=0).T
        tenants_tbl = tenants_tbl.rename(columns={0: "tenants"})

        tenants_table = pd.DataFrame()

        row_length = tenants_tbl.shape[0]

        for i in range(row_length):
            row = tenants_tbl.iloc[i]["tenants"]

            tenants_df = pd.json_normalize(
                row, max_level=0, record_path=["tenants"], meta=["reonomy_id", "msa"]
            )

            tenants_table = pd.concat([tenants_table, tenants_df])

        tenants_table = tenants_table.reset_index(drop=True)

        return tenants_table

    def handle_shapes(self, shapes_dict):
        """Transforms the shapes dictionary into a normalized pandas tables

        Args:
            shapes_dict (dict): Dictationary containing shapes data

        Returns:
            shapes_table (dataframe): normalized pandas dataframe containing shapes data
        """

        shapes_tbl = pd.json_normalize(shapes_dict, max_level=0).T
        shapes_tbl = shapes_tbl.rename(columns={0: "shapes"})

        shapes_table = pd.DataFrame()

        row_length = shapes_tbl.shape[0]

        for i in range(row_length):
            row = shapes_tbl.iloc[i]
            if "items" in row["shapes"].keys():

                shapes_df = pd.json_normalize(
                    row, max_level=0, record_path=["items"], meta=["reonomy_id", "msa"]
                )

                shapes_table = pd.concat([shapes_table, shapes_df])

        shapes_table = shapes_table.reset_index(drop=True)

        return shapes_table

    def handle_contacts(self, contacts_dict):
        """Transforms the contacts dictionary into a normalized pandas tables

        Args:
            contacts_dict (dict): Dictationary containing contacts data

        Returns:
            contacts_table (dataframe): normalized pandas dataframe containing contacts data
        """

        contacts_tbl = pd.json_normalize(contacts_dict, max_level=0).T
        contacts_tbl = contacts_tbl.rename(columns={0: "property_contacts"})

        contacts_table = pd.DataFrame()

        row_length = contacts_tbl.shape[0]

        for i in range(row_length):
            row = contacts_tbl.iloc[i]

            contacts_df = pd.json_normalize(row, max_level=0)

            contacts_table = pd.concat([contacts_table, contacts_df])

        contacts_table = contacts_table.reset_index(drop=True)

        return contacts_table

    def handle_taxes(self, taxes_dict):
        """Transforms the taxes dictionary into a normalized pandas tables

        Args:
            taxes_dict (dict): Dictationary containing taxes data

        Returns:
            taxes_table (dataframe): normalized pandas dataframe containing taxes data
        """

        taxes_tbl = pd.json_normalize(taxes_dict, max_level=0).T
        taxes_tbl = taxes_tbl.rename(columns={0: "taxes"})

        taxes_table = pd.DataFrame()

        row_length = taxes_tbl.shape[0]

        for i in range(row_length):
            row = taxes_tbl.iloc[i]["taxes"]

            propert_taxes_df = pd.json_normalize(
                row,
                max_level=0,
                record_path=["taxes"],
                meta=["reonomy_id", "tax_update_time", "msa"],
            )

            taxes_table = pd.concat([taxes_table, propert_taxes_df])

        taxes_table = taxes_table.reset_index(drop=True)

        return taxes_table