import psycopg2
import datetime
import boto3
import os
import logging

import awswrangler as wr
from dotenv import load_dotenv
import pandas as pd

from reonomy_etl.silver_transformer import SilverTransformer

logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)

# session_file_handler = logging.FileHandler("session.log")

# session_logging.addHandler(session_file_handler)

load_dotenv()

AWS_POSTGRES_PASSWORD = os.environ.get("AWS_POSTGRES_PASSWORD")


class SilverProcessor:
    """This class handles all the processing associated with handling and transforming files from the bronze S3 bucket to the silver zone.

    The purpose of this class is to fetch all the files that have yet to be processed. Load and batch them, then transform them,
    and push the newly transformed data to the silver bucket, while updating the postgres instance.

    Attributes:
        conn: Connection to the postgres instance holding all associated file metadata for the pipeline

        bucket_name: Name of the bucket we are loading data from.

        folder_session: when the processing job was started
        # TODO: Move to constant

        # TODO: create get folder_session function,
    """

    def __init__(self):
        """Initializes SilverProcessor"""
        # Connect to Postgres instance
        # TODO: Use connection function to get conn and load env variables for password
        self.conn = self.pg_connect()

        self.bucket_name = "nexus-equities-reonomy-bronze-bucket"

        now = datetime.datetime.utcnow()

        # The now instance is denominated in UTC 0 time for commonality over several time zones

        self.folder_session = (
            f"{now.year}-{now.month}-{now.day}-{now.hour}-{now.minute}"
        )

    # Fetch file functions

    def pg_connect(self):
        """Connect to postgres database instance.

        Returns:
            conn (object): psycopg2 connection object, to be used to interact with database
        """

        conn = psycopg2.connect(
            database="postgres",
            user="nexus_dev",
            password=AWS_POSTGRES_PASSWORD,  # Handle password with env file
            host="nexus-database.c0n44saktvjz.us-east-1.rds.amazonaws.com",
            port="5432",
        )
        # Connection details for AWS Relational Database Services Postgres Instance

        # session_logging.debug("Connected to Postgres Instance")

        return conn

    def fetch_processed_files(self) -> list:
        """Fetches a list of file_ids that have already been processed.

        All file_ids returned by this function will not have to be processed further, as it has been handled at a previous data.

        Returns:
            file_ids (list): _description_
        """
        cursor = self.conn.cursor()  # TODO: Change to input variable
        cursor.execute("SELECT file_id from reonomy_silver_processed_files")
        fetched_ids = cursor.fetchall()
        file_ids = [id_[0] for id_ in fetched_ids]

        return file_ids

    def fetch_all_files(self) -> list:
        """Fetches all file names from the S3 bronze bucket instance.

        All files fetched from this instance will be compared to processed files to decide which files to process in the future.

        Returns:
            all_files (list): List of all files from s3 bronze bucket zone.
        """
        s3 = boto3.resource("s3")
        my_bucket = s3.Bucket(self.bucket_name)  # TODO: Change to global variable

        all_files = []
        for object_summary in my_bucket.objects.filter(Prefix=f"scrapy/"):
            key = object_summary.key
            if key != "scrapy/":
                all_files.append(key)

        return all_files

    # File functions

    def file_name_to_id(self, file_list: list) -> list:
        """Takes the full file string and returns a list of file ids.
        These cleaned file ids will be compared to processed files.

        Args:
            file_list (list): all_files containing full strings as returned by boto, that need to be cleaned.

        Returns:
            cleaned_file_id_list (list): list of files only containing file_ids.
        """

        file_id_list = [file.split("/")[-1] for file in file_list]

        cleaned_file_id_list = [file.split(".")[0] for file in file_id_list]

        return cleaned_file_id_list

    def get_remaining_files(self, all_files: list, processed_file_ids: list) -> list:
        """Returns all files that have yet to be processed.

        Uses file_name_to_id to process all_files to all_file_ids, containing only the id strings, to compare with process files.
        As boto only takes full file names we must zip the file ids and full file names together, check if the ids have already been processed,
        and store non processed ids in files_remaining as the full id string.

        Args:
            all_files (list): all files from s3 bronze zone as full strings
            processed_file_ids (list): all files from postgres instance that have already been processed as file ids

        Returns:
            files_remaining (list): A list of full s3 url files that have yet to be processed.
        """

        all_files_ids = self.file_name_to_id(all_files)

        files_remaining = []
        for full_file, file_id in zip(all_files, all_files_ids):
            if file_id not in processed_file_ids:
                files_remaining.append(full_file)

        return files_remaining

    # Batch functions

    def get_batch_data(self, files_remaining: list) -> list:
        """Batches files into groups of 5.

        As each file contains 50 property objects, we do not want to overload the functions at a given time and
        hence batch the files into groups of 5.

        Args:
            files_remaining (list): List of full s3 url strings of unprocessed files.

        Returns:
            batches (list): List of lists containing batches of 5 files, per embedded list.
        """

        n = 5
        batches = [
            files_remaining[i : i + n] for i in range(0, len(files_remaining), n)
        ]

        return batches

    def fetch_batches(self, files_remaining):

        batches = self.get_batch_data(files_remaining)

        return batches

    # Sql functions

    def generate_sql_query(
        self, id_list: list, folder_session: str, paths: list
    ) -> str:
        """Generates the sql query for inserting data into reonomy_silver_processed_files table.

        This function takes the list of ids of the recently processed files, as well as the folder_session and the paths of the files
        that each of those file tables were processed into and generates a SQL query.

        Args:
            id_list (list): List of ids of recently processed files.
            folder_session (str): String holding the time the SilverProcesser was instantiated.
            paths (list): List of strings containing the destination paths of each table within a file batch.

        Returns:
            sql_query (str): The sql query to be inserted into reonomy_silver_processed_files postgres table.
        """

        descriptions_path = paths[0]
        sales_path = paths[1]
        tenants_path = paths[2]
        shapes_path = paths[3]
        contacts_path = paths[4]
        taxes_path = paths[5]

        tuples_to_insert = []

        for file_id in id_list:
            file_tuple = (
                file_id,
                folder_session,
                descriptions_path,
                sales_path,
                tenants_path,
                shapes_path,
                contacts_path,
                taxes_path,
            )
            tuples_to_insert.append(file_tuple)

        tuple_string = str(tuples_to_insert)

        sql_query = f"INSERT INTO reonomy_silver_processed_files(file_id, processed_date, descriptions_path, sales_path, tenants_path, shapes_path, contacts_path, taxes_path) VALUES {tuple_string[1:-1]}"

        return sql_query

    def batch_to_sql(self, batch: list, results: list, folder_session: str) -> str:
        """Processes the results and batch ids to be inserted into the generate_sql_query function.

        Args:
            batch (list): List of s3 url strings for a given batch
            results (list): list of strings containing the results returned by wrangler to_parquet method. Which in turn contains the paths of each table destination.
            folder_session (str): String holding the time the SilverProcesser was instantiated.

        Returns:
            sql_query (str): The sql query to be inserted into reonomy_silver_processed_files postgres table.
        """

        paths = [result["paths"][0] for result in results]

        file_id_list = [file.split("/")[-1] for file in batch]

        cleaned_file_id_list = [file.split(".")[0] for file in file_id_list]

        sql_query = self.generate_sql_query(cleaned_file_id_list, folder_session, paths)

        return sql_query

    def query_sql(self, query: str, conn: object):
        """Query postgres table.

        Args:
            query (str): Query to be inserted
            conn (object): connection object to postgres instance
        """

        cursor = conn.cursor()
        cursor.execute(query)

        conn.commit()
        conn.rollback()

        logger.debug("Query successful")  # TODO: Add logging

    # transformation functions

    def tables_to_parquet(self, tables: list) -> list:

        results = []

        for table, table_name in tables:

            result = wr.s3.to_parquet(
                df=table,
                dataset=True,
                path=f"s3://nexus-equities-reonomy-silver-bucket/{table_name}",
                partition_cols=["msa"],
                mode="append",
            )

            results.append(result)

        return results

    def generate_tables(self, transformed_batch: object) -> zip:
        """Extracts table attribtes from the SilverTransformer instance into a zip object of tables and table names.

        Args:
            transformed_batch (object): Current batch instance of SilverTransformer

        Returns:
            tables (zip): Zip object of tables, and their associated table names.
        """
        desc_table = transformed_batch.description_table
        sales_table = transformed_batch.sales_table
        tenants_table = transformed_batch.tenants_table
        shapes_table = transformed_batch.shapes_table
        contacts_table = transformed_batch.contacts_table
        taxes_table = transformed_batch.taxes_table

        result_tables = [
            desc_table,
            sales_table,
            tenants_table,
            shapes_table,
            contacts_table,
            taxes_table,
        ]

        table_names = [
            "descriptions",
            "sales",
            "tenants",
            "shapes",
            "contacts",
            "taxes",
        ]

        tables = zip(result_tables, table_names)

        return tables

    def transform_batch_data(self, batch_data: object) -> object:
        """Instantiates SilverTransformer object and transforms batch pandas dataframe object.

        siv_transformer object will transform and validate data, and generate the tables as attributes.

        Args:
            batch_data (pd.Dataframe): dataframe object of unnormalized batch data

        Returns:
            siv_transformer (object): Instance of SilverTransformer which contains different processed tables as attributes.
        """
        siv_transformer = SilverTransformer()

        df = siv_transformer.transform_data(batch_data)

        siv_transformer.generate_tables(df)

        return siv_transformer

    def extract_batch_data(self, batch: list) -> object:
        """Extract unnormalized data into pandas dataframe for a given batch.

        Args:
            batch (list): List of S3 urls for a given batch to be processed.

        Returns:
            data (pd.DataFrame): Pandas DataFrame containing unnormalized data for a given batch extracted from s3.
        """

        files_to_process = ["s3://" + self.bucket_name + "/" + file for file in batch]

        # Get data from batch
        data = wr.s3.read_json(path=files_to_process)
        data = data.reset_index(drop=True)

        return data

    # Loop through batches

    def process_batches(self, batches: list):
        """Iterates through batches and processes each batch using all necessary functions.

        Args:
            batches (list): List of batches containing s3 url id strings of unprocessed files.
        """

        for batch in batches:
            batch_data = self.extract_batch_data(batch)
            transformed_batch = self.transform_batch_data(batch_data)
            tables = self.generate_tables(transformed_batch)
            results = self.tables_to_parquet(tables)
            sql_query = self.batch_to_sql(batch, results, self.folder_session)
            self.query_sql(sql_query, self.conn)

        logger.info("Batches processed")
        self.conn.close()
        logger.info("Connection closed")


if __name__ == "__main__":
    processor = SilverProcessor()
