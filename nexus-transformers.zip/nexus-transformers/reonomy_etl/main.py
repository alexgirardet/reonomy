from  reonomy_etl.silver_processor import SilverProcessor

from os import path


def run_batch_job():

    import logging

    # logging.basicConfig(filename="logging.log", level=logging.INFO)

    processor = SilverProcessor()

    processed_files = processor.fetch_processed_files()

    all_files = processor.fetch_all_files()

    remaining_files = processor.get_remaining_files(all_files, processed_files)

    logging.info(f"There are: {len(remaining_files)} files to process")

    batches = processor.get_batch_data(remaining_files)

    processor.process_batches(batches)

    logging.info(f"{len(remaining_files)} files have been processed")


if __name__ == "__main__":
    run_batch_job()
